//
//  NewsAppDemoApp.swift
//  NewsAppDemo
//
//  Created by Reshma on 17/10/24.
//

import SwiftUI

@main
struct NewsAppDemoApp: App {
    
    @StateObject var articleBookmarkVM = ArticleBookmarkViewModel.shared
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(articleBookmarkVM)
        }
    }
}
