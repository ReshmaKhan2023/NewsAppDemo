//
//  RetryView.swift
//  NewsAppDemo
//
//  Created by Tork Software on 20/10/24.
//

import SwiftUI

struct RetryView: View {
    let text: String
    let retryAction: () -> ()
    
    var body: some View {
        VStack(spacing: 8) {
            Text(text)
                .font(.callout)
                .multilineTextAlignment(.center)
            
            Button(action: retryAction) {
                Text("Try Again")
            }
        }
    }
}

#Preview {
    RetryView(text: "An error occured") {
    }
    }
