//
//  Untitled.swift
//  NewsAppDemo
//
//  Created by Reshma on 20/10/24.
//

import Foundation

struct NewsAPIResponse: Decodable {
    let status: String
    let totalResults: Int?
    let articles: [Article]
    
    let code: String?
    let message: String?
}
